<?php 

namespace XBase\Exception;

class InvalidColumnException extends \InvalidArgumentException
{
}